import React from "react";
const CardInfo = () =>{
    return(
        <div>
            CardsDetails
        </div>
    );

}
export default CardInfo;