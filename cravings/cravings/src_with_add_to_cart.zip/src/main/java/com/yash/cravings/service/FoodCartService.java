package com.yash.cravings.service;

import java.util.List;

import com.yash.cravings.model.FoodCart;

public interface FoodCartService {
public FoodCart addcart(FoodCart item);
public List<FoodCart> getCartitems();
}
