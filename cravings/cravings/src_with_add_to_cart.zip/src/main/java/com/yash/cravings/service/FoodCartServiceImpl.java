package com.yash.cravings.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.cravings.model.FoodCart;
import com.yash.cravings.repository.FoodCartRepository;
@Service
public class FoodCartServiceImpl implements FoodCartService{
	@Autowired
	private FoodCartRepository foodcartrepository;

	@Override
	public FoodCart addcart(FoodCart cartitem) {
		// TODO Auto-generated method stub
		return foodcartrepository.save(cartitem);
	}

	@Override
	public List<FoodCart> getCartitems() {
		// TODO Auto-generated method stub
		return foodcartrepository.findAll();
	}
	
}
