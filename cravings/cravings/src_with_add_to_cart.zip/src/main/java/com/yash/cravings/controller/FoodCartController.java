package com.yash.cravings.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.cravings.model.FoodCart;
import com.yash.cravings.service.FoodCartService;

@RestController
@RequestMapping("/cart")
@CrossOrigin
public class FoodCartController {
	@Autowired
	private FoodCartService cartitemservice;

	@PostMapping("/addcart")
	public String add(@RequestBody FoodCart cartitems) {
		cartitemservice.addcart(cartitems);
		return "New Cart Item Added";
	}

	@GetMapping("/getcartitems")
	public List<FoodCart> getitem() {

		return cartitemservice.getCartitems();
	}

}
