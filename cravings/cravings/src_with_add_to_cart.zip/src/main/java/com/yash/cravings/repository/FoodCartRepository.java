package com.yash.cravings.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.cravings.model.FoodCart;

public interface FoodCartRepository extends JpaRepository<FoodCart,Integer> {

}
