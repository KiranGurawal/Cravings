package com.yash.cravings.service;


//import java.util.List;

import com.yash.cravings.model.Customer;


public interface CustomerService {
	public Customer saveCustomer(Customer student);
	public Customer loginCustomer(int id);
}
