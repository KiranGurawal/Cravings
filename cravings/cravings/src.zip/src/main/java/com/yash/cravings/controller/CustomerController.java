package com.yash.cravings.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.yash.cravings.model.Customer;
import com.yash.cravings.service.CustomerService;

@RestController
@RequestMapping("/customer")
@CrossOrigin
public class CustomerController {
	@Autowired
	private CustomerService customerservice;
	@PostMapping("/add")
	public String add(@RequestBody Customer customer)
	{
		customerservice.saveCustomer(customer);
		return "New Customer Added";
	}
	@RequestMapping("/id")
	public String login(@RequestBody Customer c) {
		System.out.println("Hello");
		Customer ccheck = this.customerservice.loginCustomer(c.getId());
		if (ccheck == null) {
			System.out.println("Null");
			return "Invalid username or password";
		}
		if (!ccheck.getPassword().equals(c.getPassword())) {
			System.out.println("Wrong");
			return "Invalid username or password";
		}
		return "You can login";
	}
}
