package com.yash.cravings.repository;
//This class is used for usng jpa annotations.
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yash.cravings.model.Customer;
@Repository
public interface UserRepository extends JpaRepository<Customer,Integer>{

}
