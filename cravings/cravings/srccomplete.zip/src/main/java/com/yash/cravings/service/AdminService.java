package com.yash.cravings.service;

import java.util.Optional;

import com.yash.cravings.model.Admin;

public interface AdminService {
//public Admin saveAdmin(Admin admin);
public Admin loginAdmin(String email);
}
